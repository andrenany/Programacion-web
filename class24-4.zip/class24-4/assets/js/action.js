//JQUERY es una biblioteca de JavaScript, que nos permita interactuar con el DOM y HTML
//Hacer màs con menos
//Quienes utilizan JQUERY
//Google, IBM, Netflix, Microsoft y Duoc.cl
/*
que nos permita realixzar JQUERY
-Manipular el DOM/HTML
-Manipular los estilos CSS
-Eventos de HTML
-Efectos y animaciones
-Ajax
-
*/

//$("selector": etiquetas, *, ID, class, atributos).eventos()

//probar que jquery funciona

$(document).ready(function(){
    //.hide() oculta un elemento html
    $("#parrafo1").hide();

    //agregar a css
    $("#parrafo2").css({"color":"tomato"});

    //tamanño del txto
    $("#parrafo3").css({"font-size":"20px"});
    
    //Capturar evento click
    $("#parrafo4").click(function(){
        alert(" el click funciona")
    
    });
     //Capturar evento  dobleclick
     $("#parrafo5").dblclick(function(){
        alert(" el dobleclick tambien  funciona")
    
    });

     //mouseleave se activa cuando el puntero sale de la seccion
     $("#parrafo6").mouseleave(function(){
        alert("compra el producto")
    
    });

     //mousedorw al tocarlo
     $("#parrafo7").mousedown(function(){
        alert("apretaste el boton")
    
    });
      //
      $("#parrafo8").mouseleave(function(){
        $(this).hide(); 
    });

    //trabajar con form

    $("#correo").focus(function(){
        $(this).css("background-color","silver")
    });
      //trabajar con blur

      $("#password").blur(function(){
        $(this).css("background-color","purple")
    });
});