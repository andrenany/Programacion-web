$(document).ready(function(){
    $("#mover").click(function(){
        // Aquí capturas el cuadrado y le indicas a dónde moverse
        $("#cuadrado").animate({left: "800px"});
    });

    $("#agregar").click(function(){
        let texto ="Cualquier cosa, a mi no me diga nada";

        $("#container").append('<p>' + texto +'</p>');
    });
});
