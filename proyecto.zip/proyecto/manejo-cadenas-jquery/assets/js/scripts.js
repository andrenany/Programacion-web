$(document).ready(function(){
    $("#contar").click(function(){
        //obtiene el valor del text area
        let texto =$("#texto").val();
        //aca voy a contar el texto
        let longitud =texto.length;
        $("#resultado").text("el texto tiene " +longitud+" carácteres");

    });

    $("#mayuscula").click(function(){
        //obtiene el valor del text area
        let texto =$("#texto").val();
        //aca voy a contar el texto
        let mayuscula =texto.toUpperCase();
        $("#resultado").text(mayuscula);

    });

    $("#minuscula").click(function(){
        //obtiene el valor del text area
        let texto =$("#texto").val();
        //aca voy a contar el texto
        let minuscula =texto.toLowerCase();
        $("#resultado").text(minuscula);

    });
});
