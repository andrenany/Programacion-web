/*
//entero o number
let numeroEntero =2;

//Cadenas de texto o string

let cadenaTexto ="hola soy una cadena";

//Boolenos bool

let booleanoVerdadelo= true;
let booleanoFalse= false;

//Undefined, no definido;

let noDefinida;

//Null- datos de tino nulo

let variableNula= null;

//constantes

const variableConstante= "19.020.383-9";

//como puedo saber que tipo de variable es
console.log(typeof cadenaTexto);
console.log(typeof numeroEntero);
console.log(booleanoVerdadelo);

//para definir objetos dentro de  JS{}

let estudiantes={
    nombre: " María", 
    edad: 40,
    nombreHijo: "Pedrito",
    rut: "12.334.555-9",
}
console.log(estudiantes);
//llamar a un dato especifico del objeto
console.log(estudiantes.nombreHijo);
console.log(estudiantes["nombreHijo"]);

//modificar valor especifico de un objeto

estudiantes.nombreHijo="Rafita";
console.log(estudiantes.nombreHijo);

//eliminar un valor y propiedad del objeto
delete estudiantes.rut;
console.log(estudiantes);

//Array, definis listas dentro de js []
//Array o listas, este respeta el orden de los datos.

let utiles =["Cuaderno", "Estuche", "Lapices"];

console.log(utiles);
console.log(utiles[0]);
//agregar datos al Array
utiles[3]="Goma de Borrar";
console.log(utiles);

//para solicitar datos al usuario
let numeroUno= parseInt(prompt(" Escriba el numero 1"));
let numeroDos = parseInt(prompt("Escriba el numero 2"));
let resultado = numeroUno + numeroDos;
console.log(resultado);

//Como declarar una funcion  en JS

function saludar(){
    alert("hola mundo")
}
saludar();

crear una calculadora, con funciones de sumar restar dividir multiplicar.
deben solicitar dor numeros.
*/

let numeroUno= parseInt(prompt(" Escriba el numero 1"));
let numeroDos = parseInt(prompt("Escriba el numero 2"));

function suma(numeroUno,numeroDos){
   
    let resultado = numeroUno + numeroDos;
} 
suma();

function resta(numeroUno,numeroDos){
    let resultado = numeroUno - numeroDos;
} 
resta();


let multiplo = numeroUno * numeroDos;
console.log(multiplo);

let dividir = numeroUno / numeroDos;
console.log(dividir);

