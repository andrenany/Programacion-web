//comentarios de una linea
/*
comentarios de varias lineas
*/
// se puede utilizar pero no es recomendable 
var variableantigua = " Holavar";

//variable recomendada
let variablerecomendada = "Usar esta";

//IMPRIMIR VARIABLES EN CONSOLA

/* 
class, const, continue, debugger, defaul, delete, else, export,
 finally, for, function, if, import, in, instanceof, new, return, super, switch,
this, throw, try, typeof, var, void, while, with, yield
*/

//Case sensitive, que s sensible a las mayúsculas.

let numero= 1;
let Numero= 1;
console.log(variablerecomendada)

//variables de convencion
//camelcase

let numeroPrimerio = 1;

//snakecase

let numero_primario= 1;

//Upper case

let NUMERO= 1;