let nombre = document.getElementById("nombre");
let nombreError = document.getElementById("nombreError");
let password = document.getElementById("password");
let passwordError = document.getElementById("passwordError");
let form = document.getElementById("myForm");

//agregar un evento submit al formulario
form.addEventListener("submit", function(event){
    event.preventDefault();
    validarFormulario();
});

//funcion para validar el formulario
function validarFormulario(){
    nombreError.textContent= "";
    passwordError.textContent="";

    // validar el campo nombre
    if(nombre.value === null || nombre.value.trim()===""){
        nombreError.textContent= "Completar el campo nombre";  
    }

     //validar campo password
    if(password.value === null || password.value.trim()===""){
        passwordError.textContent= "Ingresar Contraseña";  
    }
    //sino hay error entonces enviar formulario
    if(nombreError.textContent==="" && password.textContent===""){
        alert("tudu bem");
    }
};